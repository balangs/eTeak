#!/bin/sh

./teak --gui -e shifter.report -o dummy shifter.teak
