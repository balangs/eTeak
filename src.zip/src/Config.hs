module Config (
	buildTeakHome,
	teakVersion
	) where

	buildTeakHome :: String
	buildTeakHome = "/usr/local"

	teakVersion :: String
	teakVersion = "0.4"
